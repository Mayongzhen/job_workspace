package com.javaapi.reportsys;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReportsysApplicationTests {

    @Test
    void contextLoads() {
    }

}
